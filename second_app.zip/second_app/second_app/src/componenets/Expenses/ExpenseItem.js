import './ExpenseItem.css';
import ExpenseDate from './ExpenseDate';
import Card from '../UI/Card';


function ExpenseItem(props) {//here within the Propsdata parameter React is sending data from the main App.js file 
    //to each dynamic arribute with curly braces we have defined in JSX 
    /*
       const month = Propsdata.date.toLocaleString('en-US', { month: 'long' });
       //here we are extracting the month data from the date object we are getting 
       //from the props parameter
       const day=Propsdata.date.toLocaleString('en-US',{day:'2-digit'})
       const year = Propsdata.date.getFullYear();
       */
    return (
        <Card className='expense-item'>
            <ExpenseDate date={props.date}></ExpenseDate>
            {/* the alternative Syntax is a self closing tag of
                <ExpenseDate/>
             */}
            <div className="expense-item__description">
                <h2>
                    {props.title}
                </h2>
                <div className='expense-item__price'>
                    {props.amount}
                </div>
            </div>
        </Card>
    );
}
export default ExpenseItem;